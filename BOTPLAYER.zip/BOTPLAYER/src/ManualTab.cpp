#include "ManualTab.hpp"
#include <Geode/Geode.hpp>

using namespace geode::prelude;

void ManualTab::startRecording() {
    m_macro.clear();
    m_state = State::Recording;
    log::info("BOTPLAYER: mulai record macro");
}

void ManualTab::stopRecording() {
    if (m_state != State::Recording) return;
    m_state = State::Idle;
    log::info("BOTPLAYER: record selesai, {} frame tersimpan", m_macro.frames.size());
    // m_macro otomatis udah ke-isi selama onFrame() dipanggil pas recording
    // jadi "save" di sini cukup berhenti nambah frame baru (sudah tersimpan di m_macro)
}

void ManualTab::startPlayback() {
    if (m_macro.empty()) {
        // Popup yang manggil ini yang nampilin notifikasi "macro ini kosong!"
        // ManualTab cuma jaga-jaga di sisi logic juga
        log::warn("BOTPLAYER: playback dibatalkan, macro kosong");
        return;
    }
    m_state = State::Playing;
    log::info("BOTPLAYER: mulai playback ({} frame)", m_macro.frames.size());
}

void ManualTab::stopPlayback() {
    if (m_state != State::Playing) return;
    m_state = State::Idle;
    log::info("BOTPLAYER: playback dihentikan");
}

void ManualTab::onFrame(int frameIndex, bool holding) {
    switch (m_state) {
        case State::Recording: {
            // Cuma simpen frame baru kalau state input-nya beda dari sebelumnya
            // (biar nggak nyimpen ribuan frame identik, cukup titik transisi)
            if (m_macro.frames.empty() || m_macro.frames.back().holding != holding) {
                m_macro.frames.push_back(InputFrame{ frameIndex, holding });
            }
            break;
        }
        case State::Playing: {
            // Playback yang beneran "nekan tombol" dilakuin di main.cpp
            // (hook PlayLayer::update), di sini cuma nyediain data via getMacro()
            break;
        }
        case State::Idle:
        default:
            break;
    }
}
