# BOTPLAYER

Mod Geometry Dash (Geode) — bot player dengan 2 mode:
- **Manual** — rekam input pemain, save, playback ulang
- **Automatic** — AI coba mainin level & belajar pola pakai genetic algorithm

## Struktur

```
BOTPLAYER/
├── mod.json                 → metadata mod
├── CMakeLists.txt           → build config
└── src/
    ├── main.cpp              → entry point, hook ke PlayLayer & PlayerObject
    ├── MacroData.hpp         → struct data input/macro
    ├── ManualTab.hpp/.cpp    → logic record & playback
    ├── GeneticBot.hpp/.cpp   → logic populasi, fitness, evolusi
    └── BotPlayerPopup.hpp/.cpp → UI popup 2 tab
```

## Cara build

1. Install Geode CLI kalau belum: https://docs.geode-sdk.org/getting-started/
2. Dari folder project ini, jalanin:
   ```
   geode build
   ```
3. Kalau sukses, file `.geode` hasil build ada di folder `build/`
4. Import file `.geode` itu ke game (drag ke jendela Geode, atau lewat mod folder)

## Status pengerjaan

- [x] Skeleton mod.json & struktur file
- [x] Popup UI 2 tab (Manual / Automatic)
- [x] Record & playback macro (Manual)
- [x] Genetic algorithm dasar (Automatic)
- [x] Hook capture input asli (pushButton/releaseButton)
- [ ] Tombol buka popup dari pause menu
- [ ] Penyesuaian nama field API asli GD (m_currentProgress, dll) pas build pertama
- [ ] Testing & fix error compile

## Catatan

Beberapa nama API di kode (`m_gameState.m_currentProgress`, `PlayerButton::Jump`, dll)
ditulis berdasarkan pola umum Geode SDK — kemungkinan perlu disesuaikan dikit
sama header asli pas `geode build` pertama kali dijalanin.
